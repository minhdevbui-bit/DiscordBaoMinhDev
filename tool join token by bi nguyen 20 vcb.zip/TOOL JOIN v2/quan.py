import threading
import queue
import time
import random
from colorama import init, Fore, Back, Style
from api import *
from api.plugins.dchelper import DiscordHelper
from api.avatar import change_avatars
import concurrent.futures
import os
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import warnings
import json
from urllib3.exceptions import InsecureRequestWarning
import base64


init(autoreset=True)


warnings.filterwarnings('ignore', category=InsecureRequestWarning)

def create_session_with_retry():
    """Create a requests session with retry mechanism"""
    session = requests.Session()
    retry_strategy = Retry(
        total=1,  
        backoff_factor=0.1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST", "PUT", "DELETE"],
        respect_retry_after_header=True,
        raise_on_status=False
    )
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=100, pool_maxsize=100)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

def print_banner():
    banner = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════════╗
║                {Fore.YELLOW}Discord Server Joiner v2.0{Fore.CYAN}                    ║
║                  {Fore.WHITE}Created by: Hoang Minh Quan{Fore.CYAN}                     ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def print_menu():
    menu = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════════╗
║                     {Fore.YELLOW}MENU CHỌN CHỨC NĂNG{Fore.CYAN}                      ║
║                                                              ║
║  {Fore.WHITE}[1] {Fore.GREEN}Join Server{Fore.CYAN}                                             ║
║  {Fore.WHITE}[2] {Fore.GREEN}Leave Server{Fore.CYAN}                                            ║
║  {Fore.WHITE}[3] {Fore.GREEN}Đổi Tên{Fore.CYAN}                                                 ║
║  {Fore.WHITE}[4] {Fore.GREEN}Đổi Đại Từ Nhân Xưng{Fore.CYAN}                                    ║
║  {Fore.WHITE}[5] {Fore.GREEN}Check Token{Fore.CYAN}                                             ║
║  {Fore.WHITE}[6] {Fore.GREEN}Đổi Avatar{Fore.CYAN}                                              ║
║  {Fore.WHITE}[7] {Fore.RED}Thoát{Fore.CYAN}                                                   ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(menu)

def remove_token_from_file(token, should_remove=False):
    """Remove a token from tokens.txt after processing if should_remove is True"""
    if not should_remove:
        return
        
    try:
        
        with open('input/tokens.txt', 'r', encoding='utf-8') as f:
            tokens = f.read().splitlines()
        
        
        if token in tokens:
            tokens.remove(token)
            
        
        with open('input/tokens.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(tokens))
    except Exception as e:
        log.error(f"Error updating tokens.txt: {str(e)}")

def process_token(token, invite_code, proxy, stats, server_name=None, should_remove=False):
    dc_helper = DiscordHelper()
    display_token = token[:8]
    
    try:
       
        if proxy and ":" in proxy:
            try:
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    host, port = host_port.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    host, port = proxy.split(":")
                    proxy_url = f"http://{host}:{port}"
                proxy = {
                    "http": proxy_url,
                    "https": proxy_url
                }
            except:
                proxy = None
        
       
        result = dc_helper.join_server(token, invite_code, proxy)
        
        if result["status"] == "joined":
            file_manager.save_result("joined.txt", token)
            log.success(f"[ Joiner ] {display_token} đã vào thành công --> {server_name}")
            stats['joined'] += 1
            return True
                
        elif result["status"] == "captcha":
            log.captcha(f"[ Thất bại ] {display_token} --> Token đã bị dính capcha")
            stats['captcha'] += 1
            file_manager.save_result("captcha.txt", token)
            return False
                
        elif result["status"] == "verify":
            log.verify(f"[ Thất bại ] {display_token} --> Token cần được verify")
            stats['cloudflare'] += 1
            file_manager.save_result("cloudflare.txt", token)
            return False
                
        elif result["status"] == "failed":
            log.die(f"[ Thất bại ] {display_token} --> Token không thể join")
            stats['failed'] += 1
            file_manager.save_result("failed.txt", token)
            return False
            
        elif result["status"] == "error":
            error_msg = f"Token: {display_token} | Error: {result['message']} | Proxy: {proxy.get('http', 'None')}"
            log.error(f"[ Thất bại ] {display_token} --> {result['message']}")
            stats['failed'] += 1
            file_manager.save_result("errors.txt", error_msg)
            return False
            
    except Exception as e:
        error_msg = f"Token: {display_token} | Error: {str(e)} | Proxy: {proxy.get('http', 'None') if proxy else 'None'}"
        log.error(f"[ Thất bại ] {display_token} --> Lỗi: {str(e)}")
        stats['failed'] += 1
        file_manager.save_result("errors.txt", error_msg)
        return False

def process_name_change(token, new_name, proxy=None, should_remove=False):
    try:
        display_token = token[:8]
        
        
        if proxy:
            if ":" in proxy:
                host, port = proxy.split(":")
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    proxy_url = f"http://{host}:{port}"
                proxy = {
                    "http": proxy_url,
                    "https": proxy_url
                }
        
       
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        
        if proxy:
            session.proxies = proxy
        
       
        response = session.patch(
            "https://discord.com/api/v9/users/@me",
            json={"username": new_name},
            timeout=5,
            verify=False
        )
        
        if response.status_code == 200:
            log.success(f"[ Rename ] {display_token} đã đổi tên thành công --> {new_name}")
            file_manager.save_result("name_changed.txt", token)
            return True
        else:
            log.error(f"[ Thất bại ] {display_token} --> Lỗi khi đổi tên: {response.status_code}")
            return False
            
    except Exception as e:
        log.error(f"[ Thất bại ] {display_token} --> Lỗi: {str(e)}")
        return False

def process_leave(token, invite_code, proxy, stats, server_name=None, should_remove=False):
    try:
        display_token = token[:8]
        
       
        if proxy:
            if ":" in proxy:
                host, port = proxy.split(":")
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    proxy_url = f"http://{host}:{port}"
                proxy = {
                    "http": proxy_url,
                    "https": proxy_url
                }
        
       
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        
        if proxy:
            session.proxies = proxy
        
      
        response = session.delete(
            f"https://discord.com/api/v9/users/@me/guilds/{invite_code}",
            timeout=5,
            verify=False
        )
        
        if response.status_code in [200, 201, 204]:
            file_manager.save_result("left.txt", token)
            log.success(f"[ Leave ] {display_token} đã out thành công --> {server_name}")
            stats['left'] += 1
            return True
        else:
            log.error(f"[ Thất bại ] {display_token} --> Lỗi khi leave: {response.status_code}")
            stats['failed'] += 1
            return False
            
    except Exception as e:
        log.error(f"[ Thất bại ] {display_token} --> Lỗi: {str(e)}")
        stats['failed'] += 1
        return False

def process_pronouns(token, pronouns, proxy=None, should_remove=False):
    try:
        display_token = token[:8]
     
        if proxy:
            if ":" in proxy:
                host, port = proxy.split(":")
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    proxy_url = f"http://{host}:{port}"
                proxy = {
                    "http": proxy_url,
                    "https": proxy_url
                }
        
     
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        
        if proxy:
            session.proxies = proxy
        
     
        response = session.patch(
            "https://discord.com/api/v9/users/@me",
            json={"pronouns": pronouns},
            timeout=5,
            verify=False
        )
        
        if response.status_code == 200:
            log.success(f"[ Đổi đại từ nhân xưng ] {display_token} đã đổi đại từ nhân xưng thành công --> {pronouns}")
            file_manager.save_result("pronouns_changed.txt", token)
            return True
        else:
            log.error(f"[ Thất bại ] {display_token} --> Lỗi khi đổi đại từ nhân xưng: {response.status_code}")
            return False
            
    except Exception as e:
        log.error(f"[ Thất bại ] {display_token} --> Lỗi: {str(e)}")
        return False

def process_avatar_change(token, avatar_url, proxy=None, should_remove=False):
    """Process changing avatar for a single token"""
    try:
        display_token = token[:8]
        log.info(f"Đang xử lý token: {display_token}")
        
       
        if proxy:
            if ":" in proxy:
                host, port = proxy.split(":")
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    proxy_url = f"http://{host}:{port}"
                proxy = {
                    "http": proxy_url,
                    "https": proxy_url
                }
        
      
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        
        if proxy:
            session.proxies = proxy
           
            try:
                test_response = session.get("https://discord.com", timeout=5, verify=False)
                if test_response.status_code != 200:
                    log.error(f"[ Thất bại ] {display_token} --> Proxy không hoạt động")
                    return False
            except Exception as e:
                log.error(f"[ Thất bại ] {display_token} --> Không thể kết nối tới proxy: {str(e)}")
                return False
        
       
        try:
            response = session.get("https://discord.com/api/v9/users/@me", timeout=5, verify=False)
            if response.status_code != 200:
                log.error(f"[ Thất bại ] {display_token} --> Session không hợp lệ")
                file_manager.save_result("invalid_session.txt", token)
                return False
        except Exception as e:
            log.error(f"[ Thất bại ] {display_token} --> Lỗi kết nối: {str(e)}")
            return False
        
       
        max_retries = 2
        for attempt in range(max_retries):
            try:
               
                avatar_response = session.get(avatar_url, timeout=5, verify=False)
                if avatar_response.status_code != 200:
                    if attempt < max_retries - 1:
                        continue
                    log.error(f"[ Thất bại ] {display_token} --> Không thể tải avatar")
                    return False
                
              
                avatar_data = {
                    "avatar": f"data:image/png;base64,{base64.b64encode(avatar_response.content).decode()}"
                }
                
              
                change_response = session.patch(
                    "https://discord.com/api/v9/users/@me",
                    json=avatar_data,
                    timeout=5,
                    verify=False
                )
                
                if change_response.status_code == 200:
                    log.success(f"[ Đổi avt ] {display_token} đã đổi avt thành công")
                    file_manager.save_result("avatar_changed.txt", token)
                    return True
                elif change_response.status_code == 429:  # Rate limit
                    retry_after = int(change_response.headers.get('Retry-After', 2))
                    if attempt < max_retries - 1:
                        time.sleep(retry_after)
                        continue
                    log.error(f"[ Thất bại ] {display_token} --> Rate limit")
                    return False
                else:
                    if attempt < max_retries - 1:
                        continue
                    log.error(f"[ Thất bại ] {display_token} --> Lỗi khi đổi avatar: {change_response.status_code}")
                    return False
                    
            except requests.exceptions.ProxyError as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Thất bại ] {display_token} --> Lỗi proxy: {str(e)}")
                return False
            except requests.exceptions.ConnectTimeout as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Thất bại ] {display_token} --> Timeout kết nối: {str(e)}")
                return False
            except requests.exceptions.ConnectionError as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Thất bại ] {display_token} --> Lỗi kết nối: {str(e)}")
                return False
            except requests.exceptions.SSLError as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Thất bại ] {display_token} --> Lỗi SSL: {str(e)}")
                return False
            except Exception as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Thất bại ] {display_token} --> Lỗi không xác định: {str(e)}")
                return False
        
        return False
        
    except Exception as e:
        log.error(f"[ Thất bại ] {display_token} --> Lỗi: {str(e)}")
        return False

def process_token_check(token, proxy=None, should_remove=False):
    try:
        display_token = token[:8]
        
       
        if proxy:
            try:
                if ":" in proxy:
                    host, port = proxy.split(":")
                    if "@" in proxy:
                        auth, host_port = proxy.split("@")
                        username, password = auth.split(":")
                        proxy_url = f"http://{username}:{password}@{host}:{port}"
                    else:
                        proxy_url = f"http://{host}:{port}"
                    proxy = {
                        "http": proxy_url,
                        "https": proxy_url
                    }
            except Exception as e:
                log.error(f"[ Check token ] {display_token} --> Invalid proxy format")
                return False
        
        
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        
        if proxy:
            session.proxies = proxy
           
            try:
                test_response = session.get("https://discord.com", timeout=3, verify=False)
                if test_response.status_code != 200:
                    log.error(f"[ Check token ] {display_token} --> Proxy không hoạt động")
                    return False
            except Exception as e:
                log.error(f"[ Check token ] {display_token} --> Không thể kết nối tới proxy")
                return False
        
     
        max_retries = 2
        for attempt in range(max_retries):
            try:
                response = session.get("https://discord.com/api/v9/users/@me", timeout=3, verify=False)
                
                if response.status_code == 200:
                    log.success(f"[ Check token ] {display_token} --> LIVE")
                    file_manager.save_result("valid_tokens.txt", token)
                    return True
                elif response.status_code == 429:  
                    if attempt < max_retries - 1:
                        time.sleep(1)
                        continue
                    log.error(f"[ Check token ] {display_token} --> Rate limit")
                    return False
                else:
                    log.error(f"[ Check token ] {display_token} --> DIE ({response.status_code})")
                    file_manager.save_result("invalid_tokens.txt", token)
                    return False
                    
            except requests.exceptions.ProxyError:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Check token ] {display_token} --> Proxy error")
                return False
            except requests.exceptions.ConnectTimeout:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Check token ] {display_token} --> Connection timeout")
                return False
            except requests.exceptions.ConnectionError:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Check token ] {display_token} --> Connection error")
                return False
            except Exception as e:
                if attempt < max_retries - 1:
                    continue
                log.error(f"[ Check token ] {display_token} --> Error: {str(e)}")
                return False
            
    except Exception as e:
        log.error(f"[ Check token ] {display_token} --> Error: {str(e)}")
        return False

def process_batch(tokens, proxy, operation, **kwargs):
    """Process a batch of tokens with the given proxy"""
    stats = {
        'success': 0,
        'failed': 0
    }
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tokens), 1000)) as executor:
        futures = []
        
        for token in tokens:
            futures.append(executor.submit(operation, token, proxy=proxy, **kwargs))
        
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
                completed += 1
                if result:
                    stats['success'] += 1
                else:
                    stats['failed'] += 1
                
                if completed % 2 == 0:
                    log.info(f"Đã xử lý {completed}/{len(tokens)} tokens")
                    log.info(f"Thành công: {stats['success']} | Thất bại: {stats['failed']}")
            except Exception as e:
                completed += 1
                stats['failed'] += 1
                continue
    
    return stats

def get_server_info(token, proxy, invite_code):
    """Get server info with improved reliability"""
    try:
        
        if ":" in proxy:
            host, port = proxy.split(":")
            if "@" in proxy:
                auth, host_port = proxy.split("@")
                username, password = auth.split(":")
                proxy_url = f"http://{username}:{password}@{host}:{port}"
            else:
                proxy_url = f"http://{host}:{port}"
            proxy = {
                "http": proxy_url,
                "https": proxy_url
            }
        
        
        session = create_session_with_retry()
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        session.headers.update(headers)
        session.proxies = proxy
        
        
        endpoints = [
            f"https://discord.com/api/v9/invites/{invite_code}?with_counts=true&with_expiration=true",
            f"https://discord.com/api/v9/guilds/{invite_code}",
            f"https://discord.com/api/v9/invites/{invite_code}",
            f"https://discord.com/api/v9/invites/{invite_code}?inputValue={invite_code}&with_counts=true&with_expiration=true"
        ]
        
        for endpoint in endpoints:
            try:
                response = session.get(endpoint, timeout=2, verify=False)
                if response.status_code == 200:
                    server_info = response.json()
                    if "guild" in server_info and "name" in server_info["guild"]:
                        return server_info["guild"]["name"]
                    elif "name" in server_info:
                        return server_info["name"]
            except:
                continue
        
        return None
    except:
        return None

def join_server(invite_code):
    tokens = file_manager.gettokens()
    if not tokens:
        log.error("No tokens found in input/tokens.txt")
        return False
        
    clear_output_files()
    
    server_name = None
    try:
        session = create_session_with_retry()
        response = session.get(f"https://discord.com/api/v9/invites/{invite_code}?with_counts=true&with_expiration=true", 
                             timeout=1, 
                             verify=False)
        if response.status_code == 200:
            server_info = response.json()
            if "guild" in server_info and "name" in server_info["guild"]:
                server_name = server_info["guild"]["name"]
                log.info(f"Đã lấy được thông tin server: {server_name}")
    except:
        pass
    
    if not server_name:
        server_name = f"Server {invite_code}"
        log.info(f"Đã lấy được thông tin server: {server_name}")
    
    total_tokens = len(tokens)
    log.info(f"Loaded {total_tokens} tokens")
        
    proxies = file_manager.getproxies()
    if not proxies:
        log.error("No proxies found! Please add proxies to continue.")
        return False
    
    log.info(f"Loaded {len(proxies)} proxies")
    
    stats = {
        'joined': 0,
        'failed': 0,
        'captcha': 0,
        'cloudflare': 0
    }
    
    
    batch_size = 10  
    with concurrent.futures.ThreadPoolExecutor(max_workers=batch_size) as executor:
        futures = []
        
        for i, token in enumerate(tokens):
            proxy = proxies[i % len(proxies)]
            futures.append(executor.submit(process_token, token, invite_code, proxy, stats, server_name))
        
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result(timeout=1) 
                completed += 1
                if completed % 2 == 0:  
                    log.info(f"Đã xử lý {completed}/{total_tokens} tokens")
                    log.info(f"Joined: {stats['joined']} | Captcha: {stats['captcha']} | Verify: {stats['cloudflare']} | Failed: {stats['failed']}")
            except concurrent.futures.TimeoutError:
                completed += 1
                stats['failed'] += 1
                continue
            except Exception:
                completed += 1
                stats['failed'] += 1
                continue
    
    log.info(f"\nKết quả cuối cùng:")
    log.info(f"Joined: {stats['joined']}")
    log.info(f"Captcha: {stats['captcha']}")
    log.info(f"Verify: {stats['cloudflare']}")
    log.info(f"Failed: {stats['failed']}")
    
    return True

def change_names(new_name):
    tokens = file_manager.gettokens()
    if not tokens:
        log.error("Không tìm thấy token nào trong file tokens.txt")
        return False
        
    clear_output_files()
    
    proxies = file_manager.getproxies()
    if not proxies:
        log.error("No proxies found! Please add proxies to continue.")
        return False
    
    log.info(f"Loaded {len(tokens)} tokens")
    log.info(f"Loaded {len(proxies)} proxies")
    
    # Process all tokens in a single batch
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tokens), 10000)) as executor:
        futures = []
        
        for i, token in enumerate(tokens):
            proxy = proxies[i % len(proxies)]
            futures.append(executor.submit(process_name_change, token, new_name, proxy))
        
        stats = {'success': 0, 'failed': 0}
        completed = 0
        
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
                completed += 1
                if result:
                    stats['success'] += 1
                else:
                    stats['failed'] += 1
                
                if completed % 2 == 0:
                    log.info(f"Đã xử lý {completed}/{len(tokens)} tokens")
                    log.info(f"Thành công: {stats['success']} | Thất bại: {stats['failed']}")
            except Exception as e:
                completed += 1
                stats['failed'] += 1
                continue
    
    log.info(f"\nKết quả cuối cùng:")
    log.info(f"Thành công: {stats['success']}")
    log.info(f"Thất bại: {stats['failed']}")
    
    return True

def leave_server(invite_code):
    tokens = file_manager.gettokens()
    if not tokens:
        log.error("No tokens found in input/tokens.txt")
        return False
        
    clear_output_files()
    
    proxies = file_manager.getproxies()
    if not proxies:
        log.error("No proxies found! Please add proxies to continue.")
        return False
    
    log.info(f"Loaded {len(tokens)} tokens")
    log.info(f"Loaded {len(proxies)} proxies")
    
    stats = {
        'left': 0,
        'failed': 0
    }
    
   
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tokens), 10000)) as executor:
        futures = []
        
        for i, token in enumerate(tokens):
            proxy = proxies[i % len(proxies)]
            futures.append(executor.submit(process_leave, token, invite_code, proxy, stats))
        
        completed = 0
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
                completed += 1
                if completed % 2 == 0:
                    log.info(f"Đã xử lý {completed}/{len(tokens)} tokens")
                    log.info(f"Left: {stats['left']} | Failed: {stats['failed']}")
            except Exception as e:
                completed += 1
                continue
    
    log.info(f"\nKết quả cuối cùng:")
    log.info(f"Left: {stats['left']}")
    log.info(f"Failed: {stats['failed']}")
    
    return True

def change_pronouns(pronouns):
    tokens = file_manager.gettokens()
    if not tokens:
        log.error("Không tìm thấy token nào trong file tokens.txt")
        return False
        
    clear_output_files()
    
    proxies = file_manager.getproxies()
    if not proxies:
        log.error("No proxies found! Please add proxies to continue.")
        return False
    
    log.info(f"Loaded {len(tokens)} tokens")
    log.info(f"Loaded {len(proxies)} proxies")
    
    # Process all tokens in a single batch
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tokens), 10000)) as executor:
        futures = []
        
        for i, token in enumerate(tokens):
            proxy = proxies[i % len(proxies)]
            futures.append(executor.submit(process_pronouns, token, pronouns, proxy))
        
        stats = {'success': 0, 'failed': 0}
        completed = 0
        
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
                completed += 1
                if result:
                    stats['success'] += 1
                else:
                    stats['failed'] += 1
                
                if completed % 2 == 0:
                    log.info(f"Đã xử lý {completed}/{len(tokens)} tokens")
                    log.info(f"Thành công: {stats['success']} | Thất bại: {stats['failed']}")
            except Exception as e:
                completed += 1
                stats['failed'] += 1
                continue
    
    log.info(f"\nKết quả cuối cùng:")
    log.info(f"Thành công: {stats['success']}")
    log.info(f"Thất bại: {stats['failed']}")
    
    return True

def check_tokens():
    tokens = file_manager.gettokens()
    if not tokens:
        log.error("Không tìm thấy token nào trong file tokens.txt")
        return False
        
    clear_output_files()
        
    proxies = file_manager.getproxies()
    if not proxies:
        log.error("No proxies found! Please add proxies to continue.")
        return False
    
    log.info(f"Loaded {len(tokens)} tokens")
    log.info(f"Loaded {len(proxies)} proxies")
        
    # Process tokens in smaller batches
    batch_size = 3
    stats = {'valid': 0, 'invalid': 0}
    
    for i in range(0, len(tokens), batch_size):
        batch_tokens = tokens[i:i + batch_size]
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=batch_size) as executor:
            futures = []
            
            for token in batch_tokens:
                proxy = proxies[i % len(proxies)]
                futures.append(executor.submit(process_token_check, token, proxy))
            
            try:
                for future in concurrent.futures.as_completed(futures, timeout=5):
                    try:
                        result = future.result()
                        if result:
                            stats['valid'] += 1
                        else:
                            stats['invalid'] += 1
                    except Exception:
                        stats['invalid'] += 1
                        continue
            except concurrent.futures.TimeoutError:
                for future in futures:
                    if not future.done():
                        future.cancel()
            
            
            log.info(f"Đã xử lý {min(i + batch_size, len(tokens))}/{len(tokens)} tokens")
            log.info(f"Valid: {stats['valid']} | Invalid: {stats['invalid']}")
            
            
            time.sleep(0.1)
    
    log.info(f"\nKết quả cuối cùng:")
    log.info(f"Valid: {stats['valid']}")
    log.info(f"Invalid: {stats['invalid']}")
    
    return True

def clear_output_files():
    """Clear all output files before starting a new operation"""
    try:
        output_files = [
            "joined.txt",
            "left.txt",
            "name_changed.txt",
            "pronouns_changed.txt",
            "invalid_tokens.txt",
            "captcha.txt",
            "cloudflare.txt",
            "failed.txt",
            "failed_leave.txt",
            "errors.txt",
            "valid_tokens.txt",
            "verify_tokens.txt",
            "error_tokens.txt",
            "expired_tokens.txt",
            "avatar_changed.txt",
            "session_error.txt",
            "died_after_join.txt" 
        ]
        
        for file in output_files:
            file_path = os.path.join("output", file)
            if os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write('')
    except Exception as e:
        log.error(f"Error clearing output files: {str(e)}")

def create_output_structure():
    """Create output folder and files if they don't exist"""
    try:
        
        if not os.path.exists("output"):
            os.makedirs("output")
            log.info("Đã tạo folder output")
            
        
        output_files = [
            "joined.txt",
            "left.txt",
            "name_changed.txt",
            "pronouns_changed.txt",
            "invalid_tokens.txt",
            "captcha.txt",
            "cloudflare.txt",
            "failed.txt",
            "failed_leave.txt",
            "errors.txt",
            "valid_tokens.txt",
            "verify_tokens.txt",
            "error_tokens.txt"
        ]
        
       
        for file in output_files:
            file_path = os.path.join("output", file)
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    pass
                log.info(f"Đã tạo file {file}")
                
    except Exception as e:
        log.error(f"Lỗi khi tạo cấu trúc output: {str(e)}")

def extract_invite_code(invite_link):
    """Extract invite code from various Discord invite link formats"""
    try:
       
        invite_link = invite_link.strip().rstrip('/')
        
       
        if 'discord.gg/' in invite_link:
            code = invite_link.split('discord.gg/')[-1]
            return code
            
        
        if 'discord.com/invite/' in invite_link:
            code = invite_link.split('discord.com/invite/')[-1]
            return code
            
        
        if 'discord.com/channels/' in invite_link:
            parts = invite_link.split('discord.com/channels/')[-1].split('/')
            if len(parts) >= 2:
                return parts[1]  
                
        
        return invite_link
        
    except Exception as e:
        log.error(f"Error extracting invite code: {str(e)}")
        return invite_link

def main():
    print_banner()
    
    
    create_output_structure()
    
    
    if auto_update.check_for_updates():
        if input("New version available. Update now? (y/n): ").lower() == 'y':
            auto_update.update()
    
    while True:
        try:
            print_menu()
            choice = input(f"{Fore.YELLOW}Chọn chức năng (1-7): {Fore.WHITE}").strip()
            
            if choice == "1":
                invite_link = input(f"{Fore.YELLOW}Enter Discord invite link or code (e.g., https://discord.gg/AbC123) or 'back' to return: {Fore.WHITE}").strip()
                
                if invite_link.lower() == 'back':
                    continue
                    
                invite_code = extract_invite_code(invite_link)
                if join_server(invite_code):
                    continue
                else:
                    break
                    
            elif choice == "2":
                invite_link = input(f"{Fore.YELLOW}Enter Discord invite link or code (e.g., https://discord.gg/AbC123) or 'back' to return: {Fore.WHITE}").strip()
                
                if invite_link.lower() == 'back':
                    continue
                    
                invite_code = extract_invite_code(invite_link)
                if leave_server(invite_code):
                    continue
                else:
                    break
                    
            elif choice == "3":
                new_name = input(f"{Fore.YELLOW}Enter new name or 'back' to return: {Fore.WHITE}").strip()
                
                if new_name.lower() == 'back':
                    continue
                    
                if change_names(new_name):
                    continue
                    
            elif choice == "4":
                pronouns = input(f"{Fore.YELLOW}Enter new pronouns or 'back' to return: {Fore.WHITE}").strip()
                
                if pronouns.lower() == 'back':
                    continue
                    
                if change_pronouns(pronouns):
                    continue
                    
            elif choice == "5":
                if check_tokens():
                    continue
                    
            elif choice == "6":
                avatar_url = input(f"{Fore.YELLOW}Enter Discord CDN avatar URL (e.g., https://cdn.discordapp.com/avatars/...) or 'back' to return: {Fore.WHITE}").strip()
                
                if avatar_url.lower() == 'back':
                    continue
                    
                if change_avatars(avatar_url):
                    continue
                    
            elif choice == "7":
                break
                
            else:
                log.error("Invalid choice. Please try again.")
                time.sleep(0.1)
                continue
                
        except Exception as e:
            log.error(f"An error occurred: {str(e)}")
            time.sleep(0.1)
            continue
    
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()