import logging
from colorama import init, Fore, Style
import time

init(autoreset=True)

class Logger:
    def __init__(self):
        self.logger = logging.getLogger('discord_joiner')
        self.logger.setLevel(logging.INFO)
        
        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(message)s')
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
        
        # File handler
        fh = logging.FileHandler('output/debug.txt')
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(fh)

    def success(self, message):
        print(f"{Fore.GREEN}[ SUCCESS ] {message}{Style.RESET_ALL}")

    def error(self, message):
        print(f"{Fore.RED}[ ERROR ] {message}{Style.RESET_ALL}")

    def warning(self, message):
        print(f"{Fore.YELLOW}[ WARNING ] {message}{Style.RESET_ALL}")

    def info(self, message):
        print(f"{Fore.BLUE}[ INFO ] {message}{Style.RESET_ALL}")

    def debug(self, message):
        print(f"{Fore.CYAN}[ DEBUG ] {message}{Style.RESET_ALL}")

    def captcha(self, message):
        print(f"{Fore.YELLOW}[ CAPTCHA ] {message}{Style.RESET_ALL}")

    def verify(self, message):
        print(f"{Fore.RED}[ VERIFY ] {message}{Style.RESET_ALL}")

    def die(self, message):
        print(f"{Fore.RED}[ DIE ] {message}{Style.RESET_ALL}")

    def dbg(self, prefix, message):
        print(f"{Fore.CYAN}[ {prefix} ] {message}{Style.RESET_ALL}")

log = Logger() 