import os
import json
import time
import random
from .log import *
from typing import List, Optional

class FileManager:
    def __init__(self):
        self.settings_version = 1.004
        self.newest_settings = {
            "version": 1.004,
            "advanced-mode": False,
            "threads": 2,
            "proxies": True,
            "onlinetokens (BETTER BYPASS)": True,
            "usesolver": False,
            "solvertype (can use: razorcap)": "",
            "solverapikey": "",
            "SOLVERSITES": "razorcap >> razorcap.xyz"
        }
        self.dirs = [
            'input',
            'output',
            'output/scrapes',
            'output/scrapes/ids',
            'output/scrapes/usernames',
        ]
        self.files = [
            'settings.json',
            'input/tokens.txt',
            'input/proxies.txt',
            'output/errors.txt',
            'output/output.txt',
            'output/debug.txt'
        ]
        self.writecfg()
        self.check()
        if not self.check_settings_update():
            self.update_settings()
        self.input_dir = "input"
        self.output_dir = "output"
        self._ensure_directories()

    def _ensure_directories(self):
        """Ensure input and output directories exist"""
        for directory in [self.input_dir, self.output_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory)
                log.info(f"Created directory: {directory}")

    def check(self):
        for dir in self.dirs:
            if not os.path.exists(dir):
                os.mkdir(dir)

        for file in self.files:
            if not os.path.exists(file):
                with open(file, 'w'):
                    pass

    def writecfg(self):
        if not os.path.exists('settings.json'):
            with open('settings.json', 'w') as f:
                json.dump(self.newest_settings, f, indent=4)

    def check_settings_update(self):
        with open('settings.json', 'r+') as f:
            content = f.read().strip()
            if not content:
                json.dump(self.newest_settings, f, indent=4)
                time.sleep(0.3)
            setts = json.loads(content)
            if float(setts['version']) != float(self.settings_version):
                return False
            return True

    def update_settings(self):
        with open('settings.json', 'r') as f:
            setts = json.load(f)

        if setts['version'] != self.settings_version:
            for key, value in self.newest_settings.items():
                if key == 'version':
                    setts[key] = value
                elif key in setts:
                    continue
                else:
                    setts[key] = value 

            with open('settings.json', 'w') as f:
                json.dump(setts, f, indent=4)
        else:
            pass

    def gettokens(self) -> List[str]:
        """Get tokens from input/tokens.txt"""
        try:
            token_file = os.path.join(self.input_dir, "tokens.txt")
            if not os.path.exists(token_file):
                log.error("tokens.txt not found in input directory")
                return []
                
            with open(token_file, "r", encoding="utf-8") as f:
                tokens = [line.strip() for line in f if line.strip()]
                
            log.info(f"Loaded {len(tokens)} tokens")
            return tokens
            
        except Exception as e:
            log.error(f"Error loading tokens: {str(e)}")
            return []

    def getproxies(self) -> List[str]:
        """Get proxies from input/proxies.txt"""
        try:
            proxy_file = os.path.join(self.input_dir, "proxies.txt")
            if not os.path.exists(proxy_file):
                log.warning("proxies.txt not found in input directory")
                return []
                
            with open(proxy_file, "r", encoding="utf-8") as f:
                proxies = [line.strip() for line in f if line.strip()]
                
            log.info(f"Loaded {len(proxies)} proxies")
            return proxies
            
        except Exception as e:
            log.error(f"Error loading proxies: {str(e)}")
            return []

    def getproxystatus(self) -> bool:
        """Check if proxies are enabled"""
        proxy_file = os.path.join(self.input_dir, "proxies.txt")
        return os.path.exists(proxy_file)

    def getthreads(self) -> int:
        """Get number of threads to use"""
        return 5  # Default to 5 threads

    def getsolverapikey(self):
        with open('settings.json', 'r') as f:
            setts = json.load(f)['solverapikey']
        return setts

    def getsolvertype(self):
        with open('settings.json', 'r') as f:
            setts = json.load(f)['solvertype (can use: razorcap)']
        return setts

    def getsolverstatus(self):  
        with open('settings.json', 'r') as f:
            setts = json.load(f)['usesolver']
        return setts
    
    def getonlinetokensstatus(self):  
        with open('settings.json', 'r') as f:
            setts = json.load(f)['onlinetokens (BETTER BYPASS)']
        return setts

    def save_result(self, filename: str, content: str):
        """Save result to output file"""
        try:
            output_file = os.path.join(self.output_dir, filename)
            with open(output_file, "a", encoding="utf-8") as f:
                f.write(f"{content}\n")
        except Exception as e:
            log.error(f"Error saving to {filename}: {str(e)}")

file_manager = FileManager() 