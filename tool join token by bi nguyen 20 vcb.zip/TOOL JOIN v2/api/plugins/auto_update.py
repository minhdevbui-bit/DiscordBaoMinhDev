import requests
import json
import os
from .log import log

class AutoUpdate:
    def __init__(self):
        self.latest_release_url = "https://github.com/r3cik/LimeV2-FREE/releases/latest"
        self.current_version = "1.0.0"

    def check_for_updates(self):
        try:
            response = requests.get(self.latest_release_url)
            if response.status_code == 200:
                latest_version = response.url.split('/')[-1]
                if latest_version != self.current_version:
                    log.info(f"New version available: {latest_version}")
                    return True
            return False
        except Exception as e:
            log.error(f"Failed to check for updates: {str(e)}")
            return False

    def update(self):
        try:
            
            log.info("Updating to latest version...")
            
            return True
        except Exception as e:
            log.error(f"Failed to update: {str(e)}")
            return False

auto_update = AutoUpdate() 