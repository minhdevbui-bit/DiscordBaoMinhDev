import tls_client
import random
import json
import time
import threading
import queue
import asyncio
import aiohttp
from typing import Optional, Dict, Any, List
from concurrent.futures import ThreadPoolExecutor
import base64
import requests

class DiscordHelper:
    def __init__(self):
        self.session = tls_client.Session(
            client_identifier="chrome_120",
            random_tls_extension_order=True,
            ja3_string="771,4865-4867-4866-49195-49199-52393-52392-49196-49200-49162-49161-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-34-51-43-13-45-28-21,29-23-24-25-256-257,0",
            h2_settings={
                "HEADER_TABLE_SIZE": 65536,
                "MAX_CONCURRENT_STREAMS": 1000,
                "INITIAL_WINDOW_SIZE": 6291456,
                "MAX_HEADER_LIST_SIZE": 262144
            },
            h2_settings_order=[
                "HEADER_TABLE_SIZE",
                "MAX_CONCURRENT_STREAMS",
                "INITIAL_WINDOW_SIZE",
                "MAX_HEADER_LIST_SIZE"
            ],
            supported_signature_algorithms=[
                "ECDSAWithP256AndSHA256",
                "PSSWithSHA256",
                "PKCS1WithSHA256",
                "ECDSAWithP384AndSHA384",
                "PSSWithSHA384",
                "PKCS1WithSHA384",
                "PSSWithSHA512",
                "PKCS1WithSHA512"
            ],
            supported_versions=["GREASE", "1.3", "1.2"],
            key_share_curves=["GREASE", "X25519"],
            cert_compression_algo="brotli",
            pseudo_header_order=[
                ":method",
                ":authority",
                ":scheme",
                ":path"
            ],
            connection_flow=15663105,
            priority_frames=[
                {
                    "streamID": 3,
                    "priorityParam": {
                        "weight": 201,
                        "streamDep": 0,
                        "exclusive": False
                    }
                },
                {
                    "streamID": 5,
                    "priorityParam": {
                        "weight": 101,
                        "streamDep": 0,
                        "exclusive": False
                    }
                }
            ],
            header_order=[
                "accept",
                "user-agent",
                "accept-language",
                "accept-encoding",
                "content-type",
                "authorization",
                "origin",
                "referer",
                "sec-ch-ua",
                "sec-ch-ua-mobile",
                "sec-ch-ua-platform",
                "sec-fetch-dest",
                "sec-fetch-mode",
                "sec-fetch-site",
                "x-debug-options",
                "x-discord-locale",
                "x-super-properties"
            ]
        )
        self.proxy_cache = set()
        self.proxy_lock = threading.Lock()
        
    def get_headers(self, token: str, invite_code: str = "") -> Dict[str, str]:
        """Generate headers for Discord API requests"""
        # Generate random client build number
        client_build = random.randint(251000, 252000)
        
        # Generate random x-super-properties with more realistic values
        x_super = {
            "os": "Windows",
            "browser": "Chrome",
            "device": "",
            "system_locale": "en-US",
            "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "browser_version": "120.0.0.0",
            "os_version": "10",
            "referrer": f"https://discord.com/invite/{invite_code}" if invite_code else "https://discord.com",
            "referring_domain": "discord.com",
            "referrer_current": f"https://discord.com/invite/{invite_code}" if invite_code else "https://discord.com",
            "referring_domain_current": "discord.com",
            "release_channel": "stable",
            "client_build_number": client_build,
            "client_event_source": None,
            "design_id": 0
        }
        
        # Properly encode x-super-properties using base64
        x_super_encoded = base64.b64encode(json.dumps(x_super).encode('utf-8')).decode('utf-8')
        
        # Generate random fingerprint
        fingerprint = ''.join(random.choices('0123456789abcdef', k=32))
        
        return {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "accept-encoding": "gzip, deflate, br",
            "authorization": token,
            "content-type": "application/json",
            "origin": "https://discord.com",
            "referer": f"https://discord.com/invite/{invite_code}" if invite_code else "https://discord.com",
            "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": x_super_encoded,
            "x-fingerprint": fingerprint
        }

    def check_proxy(self, proxy: str) -> bool:
        """Check if a proxy is working"""
        try:
            session = tls_client.Session(
                client_identifier="chrome_120",
                random_tls_extension_order=True
            )
            
            # Parse proxy format
            if ":" in proxy:
                host, port = proxy.split(":")
                if "@" in proxy:
                    auth, host_port = proxy.split("@")
                    username, password = auth.split(":")
                    proxy_url = f"http://{username}:{password}@{host}:{port}"
                else:
                    proxy_url = f"http://{host}:{port}"
                    
                session.proxies = {
                    "http": proxy_url,
                    "https": proxy_url
                }
                
                # Test proxy with a simple request
                response = session.get(
                    "https://discord.com",
                    timeout_seconds=5
                )
                
                return response.status_code in [200, 403, 401]
        except:
            return False

    def create_session(self, proxy: Optional[str] = None) -> tls_client.Session:
        """Create a new session with proper configuration"""
        # Generate random client build number
        client_build = random.randint(251000, 252000)
        
        # Generate random JA3 string
        ja3_string = "771,4865-4867-4866-49195-49199-52393-52392-49196-49200-49162-49161-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-34-51-43-13-45-28-21,29-23-24-25-256-257,0"
        
        session = tls_client.Session(
            client_identifier="chrome_120",
            random_tls_extension_order=True,
            ja3_string=ja3_string,
            h2_settings={
                "HEADER_TABLE_SIZE": 65536,
                "MAX_CONCURRENT_STREAMS": 1000,
                "INITIAL_WINDOW_SIZE": 6291456,
                "MAX_HEADER_LIST_SIZE": 262144
            },
            h2_settings_order=[
                "HEADER_TABLE_SIZE",
                "MAX_CONCURRENT_STREAMS",
                "INITIAL_WINDOW_SIZE",
                "MAX_HEADER_LIST_SIZE"
            ],
            supported_signature_algorithms=[
                "ECDSAWithP256AndSHA256",
                "PSSWithSHA256",
                "PKCS1WithSHA256",
                "ECDSAWithP384AndSHA384",
                "PSSWithSHA384",
                "PKCS1WithSHA384",
                "PSSWithSHA512",
                "PKCS1WithSHA512"
            ],
            supported_versions=["GREASE", "1.3", "1.2"],
            key_share_curves=["GREASE", "X25519"],
            cert_compression_algo="brotli",
            pseudo_header_order=[
                ":method",
                ":authority",
                ":scheme",
                ":path"
            ],
            connection_flow=15663105,
            priority_frames=[
                {
                    "streamID": 3,
                    "priorityParam": {
                        "weight": 201,
                        "streamDep": 0,
                        "exclusive": False
                    }
                },
                {
                    "streamID": 5,
                    "priorityParam": {
                        "weight": 101,
                        "streamDep": 0,
                        "exclusive": False
                    }
                }
            ],
            header_order=[
                "accept",
                "user-agent",
                "accept-language",
                "accept-encoding",
                "content-type",
                "authorization",
                "origin",
                "referer",
                "sec-ch-ua",
                "sec-ch-ua-mobile",
                "sec-ch-ua-platform",
                "sec-fetch-dest",
                "sec-fetch-mode",
                "sec-fetch-site",
                "x-debug-options",
                "x-discord-locale",
                "x-super-properties",
                "x-fingerprint"
            ]
        )
        
        if proxy and self.check_proxy(proxy):
            try:
                # Parse proxy format
                if ":" in proxy:
                    host, port = proxy.split(":")
                    if "@" in proxy:
                        auth, host_port = proxy.split("@")
                        username, password = auth.split(":")
                        proxy_url = f"http://{username}:{password}@{host}:{port}"
                    else:
                        proxy_url = f"http://{host}:{port}"
                        
                    session.proxies = {
                        "http": proxy_url,
                        "https": proxy_url
                    }
            except:
                pass
                
        return session

    def get_invite_info(self, session: tls_client.Session, invite_code: str, headers: Dict[str, str]) -> Dict[str, Any]:
        """Get invite information before joining"""
        try:
            # Add random delay between 2-4 seconds to simulate human behavior
            time.sleep(random.uniform(2, 4))
            
            # First visit the invite page to get cookies
            session.get(
                f"https://discord.com/invite/{invite_code}",
                headers=headers,
                timeout_seconds=30
            )
            
            # Add random delay between 1-2 seconds
            time.sleep(random.uniform(1, 2))
            
            # Then get invite info
            response = session.get(
                url=f"https://discord.com/api/v9/invites/{invite_code}?inputValue={invite_code}&with_counts=true&with_expiration=true",
                headers=headers,
                timeout_seconds=30
            )
            
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            with open('output/errors.txt', 'a', encoding='utf-8') as f:
                f.write(f"Error getting invite info: {str(e)}\n")
            return None

    def join_server(self, token: str, invite_code: str, proxy: Optional[str] = None) -> Dict[str, Any]:
        """Join a Discord server using the provided token and invite code"""
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                session = self.create_session(proxy)
                headers = self.get_headers(token, invite_code)
                
                # First get invite info to simulate human behavior
                invite_info = self.get_invite_info(session, invite_code, headers)
                if not invite_info:
                    retry_count += 1
                    if retry_count < max_retries:
                        time.sleep(random.uniform(2, 4))
                        continue
                    return {
                        "success": False,
                        "status": "failed",
                        "message": "Failed to get invite info"
                    }
                
                # Add random delay between 3-5 seconds to simulate human behavior
                time.sleep(random.uniform(3, 5))
                
                # Join server with more realistic data
                join_url = f"https://discord.com/api/v9/invites/{invite_code}"
                join_data = {
                    "session_id": str(random.randint(100000000000000000, 999999999999999999)),
                    "channel_id": invite_info.get("channel", {}).get("id", ""),
                    "guild_id": invite_info.get("guild", {}).get("id", ""),
                    "context_properties": {
                        "location": "Accept Invite Page",
                        "location_guild_id": invite_info.get("guild", {}).get("id", ""),
                        "location_channel_id": invite_info.get("channel", {}).get("id", ""),
                        "location_channel_type": 0
                    }
                }
                
                try:
                    response = session.post(
                        url=join_url,
                        json=join_data,
                        headers=headers,
                        timeout_seconds=30
                    )
                    
                    if response.status_code == 200:
                        return {
                            "success": True,
                            "status": "joined",
                            "message": "Successfully joined server"
                        }
                    elif "captcha_sitekey" in response.text:
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} hit captcha\n")
                        return {
                            "success": False,
                            "status": "captcha",
                            "message": "Captcha required"
                        }
                    elif response.status_code == 403 and "cloudflare" in response.text.lower():
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} needs verification\n")
                        return {
                            "success": False,
                            "status": "verify",
                            "message": "Token needs verification"
                        }
                    else:
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} failed to join: {response.text}\n")
                        return {
                            "success": False,
                            "status": "failed",
                            "message": f"Failed to join: {response.text}"
                        }
                except Exception as e:
                    if "timeout" in str(e).lower() or "certificate" in str(e).lower():
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                    with open('output/errors.txt', 'a', encoding='utf-8') as f:
                        f.write(f"Error with token {token}: {str(e)}\n")
                    raise e
                    
            except Exception as e:
                retry_count += 1
                if retry_count < max_retries:
                    time.sleep(random.uniform(2, 4))
                    continue
                with open('output/errors.txt', 'a', encoding='utf-8') as f:
                    f.write(f"Error with token {token}: {str(e)}\n")
                return {
                    "success": False,
                    "status": "error",
                    "message": str(e)
                }
                
        return {
            "success": False,
            "status": "failed",
            "message": "Max retries exceeded"
        }

    def change_name(self, token: str, new_name: str, proxy: Optional[str] = None) -> Dict[str, Any]:
        """Change display name using the provided token"""
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                session = self.create_session(proxy)
                headers = self.get_headers(token, "")
                
                # Add random delay between 1-2 seconds to simulate human behavior
                time.sleep(random.uniform(1, 2))
                
                # Change display name
                change_url = "https://discord.com/api/v9/users/@me"
                change_data = {
                    "global_name": new_name
                }
                
                try:
                    response = session.patch(
                        url=change_url,
                        json=change_data,
                        headers=headers,
                        timeout_seconds=30
                    )
                    
                    if response.status_code == 200:
                        return {
                            "success": True,
                            "status": "success",
                            "message": "Successfully changed display name"
                        }
                    elif "captcha_sitekey" in response.text:
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} hit captcha\n")
                        return {
                            "success": False,
                            "status": "captcha",
                            "message": "Captcha required"
                        }
                    elif response.status_code == 403 and "cloudflare" in response.text.lower():
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} needs verification\n")
                        return {
                            "success": False,
                            "status": "verify",
                            "message": "Token needs verification"
                        }
                    else:
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                        with open('output/errors.txt', 'a', encoding='utf-8') as f:
                            f.write(f"Token {token} failed to change name: {response.text}\n")
                        return {
                            "success": False,
                            "status": "failed",
                            "message": f"Failed to change name: {response.text}"
                        }
                except Exception as e:
                    if "timeout" in str(e).lower() or "certificate" in str(e).lower():
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                    with open('output/errors.txt', 'a', encoding='utf-8') as f:
                        f.write(f"Error with token {token}: {str(e)}\n")
                    raise e
                    
            except Exception as e:
                retry_count += 1
                if retry_count < max_retries:
                    time.sleep(random.uniform(2, 4))
                    continue
                with open('output/errors.txt', 'a', encoding='utf-8') as f:
                    f.write(f"Error with token {token}: {str(e)}\n")
                return {
                    "success": False,
                    "status": "error",
                    "message": str(e)
                }
                
        return {
            "success": False,
            "status": "failed",
            "message": "Max retries exceeded"
        }

    def leave_server(self, token: str, invite_code: str, proxy: Optional[str] = None) -> Dict[str, Any]:
        """Leave a Discord server using the provided token and invite code"""
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                session = self.create_session(proxy)
                headers = self.get_headers(token, invite_code)
                
                # Add random delay between 1-2 seconds to simulate human behavior
                time.sleep(random.uniform(1, 2))
                
                # First get invite info to get server ID
                try:
                    invite_response = session.get(
                        url=f"https://discord.com/api/v9/invites/{invite_code}?inputValue={invite_code}&with_counts=true&with_expiration=true",
                        headers=headers,
                        timeout_seconds=10
                    )
                    
                    if invite_response.status_code == 200:
                        invite_data = invite_response.json()
                        server_id = invite_data.get("guild", {}).get("id")
                        
                        if not server_id:
                            return {
                                "success": False,
                                "status": "failed",
                                "message": "Could not get server ID from invite"
                            }
                            
                        # Add random delay between 2-3 seconds
                        time.sleep(random.uniform(2, 3))
                        
                        # Try to leave the server with proper headers
                        leave_headers = headers.copy()
                        leave_headers.update({
                            "referer": f"https://discord.com/invite/{invite_code}",
                            "origin": "https://discord.com",
                            "sec-fetch-site": "same-origin",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-dest": "empty",
                            "x-context-properties": json.dumps({
                                "location": "Accept Invite Page",
                                "location_guild_id": server_id,
                                "location_channel_id": invite_data.get("channel", {}).get("id"),
                                "location_channel_type": 0
                            })
                        })
                        
                        # Try POST method first
                        try:
                            response = session.post(
                                url=f"https://discord.com/api/v9/guilds/{server_id}/leave",
                                headers=leave_headers,
                                json={},  # Empty JSON body
                                timeout_seconds=10
                            )
                            
                            if response.status_code in [200, 204]:
                                return {
                                    "success": True,
                                    "status": "left",
                                    "message": "Successfully left server"
                                }
                        except:
                            pass
                            
                        # If POST fails, try DELETE method
                        response = session.delete(
                            url=f"https://discord.com/api/v9/users/@me/guilds/{server_id}",
                            headers=leave_headers,
                            json={},  # Empty JSON body
                            timeout_seconds=10
                        )
                        
                        if response.status_code == 204:
                            return {
                                "success": True,
                                "status": "left",
                                "message": "Successfully left server"
                            }
                        elif "captcha_sitekey" in response.text:
                            with open('output/errors.txt', 'a', encoding='utf-8') as f:
                                f.write(f"Token {token} hit captcha\n")
                            return {
                                "success": False,
                                "status": "captcha",
                                "message": "Captcha required"
                            }
                        elif response.status_code == 403 and "cloudflare" in response.text.lower():
                            with open('output/errors.txt', 'a', encoding='utf-8') as f:
                                f.write(f"Token {token} needs verification\n")
                            return {
                                "success": False,
                                "status": "verify",
                                "message": "Token needs verification"
                            }
                        else:
                            retry_count += 1
                            if retry_count < max_retries:
                                time.sleep(random.uniform(2, 4))
                                continue
                            with open('output/errors.txt', 'a', encoding='utf-8') as f:
                                f.write(f"Token {token} failed to leave: {response.text}\n")
                            return {
                                "success": False,
                                "status": "failed",
                                "message": f"Failed to leave: {response.text}"
                            }
                    else:
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                        return {
                            "success": False,
                            "status": "failed",
                            "message": "Failed to get invite info"
                        }
                except Exception as e:
                    if "timeout" in str(e).lower() or "certificate" in str(e).lower():
                        retry_count += 1
                        if retry_count < max_retries:
                            time.sleep(random.uniform(2, 4))
                            continue
                    with open('output/errors.txt', 'a', encoding='utf-8') as f:
                        f.write(f"Error with token {token}: {str(e)}\n")
                    raise e
                    
            except Exception as e:
                retry_count += 1
                if retry_count < max_retries:
                    time.sleep(random.uniform(2, 4))
                    continue
                with open('output/errors.txt', 'a', encoding='utf-8') as f:
                    f.write(f"Error with token {token}: {str(e)}\n")
                return {
                    "success": False,
                    "status": "error",
                    "message": str(e)
                }
                
        return {
            "success": False,
            "status": "failed",
            "message": "Max retries exceeded"
        }

    def change_pronouns(self, token, pronouns, proxy=None):
        """Change user pronouns"""
        try:
            session = self.create_session(proxy)
            headers = self.get_headers(token)
            
            # Add random delay
            time.sleep(random.uniform(1, 2))
            
            # Get current user data first
            user_response = session.get(
                "https://discord.com/api/v9/users/@me",
                headers=headers,
                timeout_seconds=10
            )
            
            if user_response.status_code == 200:
                user_data = user_response.json()
                
                # Update pronouns
                payload = {
                    "pronouns": pronouns
                }
                
                # Send PATCH request to update pronouns
                response = session.patch(
                    "https://discord.com/api/v9/users/@me",
                    headers=headers,
                    json=payload,
                    timeout_seconds=10
                )
                
                if response.status_code == 200:
                    return {
                        "status": "success",
                        "message": "Pronouns updated successfully"
                    }
                elif response.status_code == 429:
                    retry_after = response.json().get('retry_after', 5)
                    time.sleep(retry_after)
                    return self.change_pronouns(token, pronouns, proxy)
                else:
                    return {
                        "status": "failed",
                        "message": f"Failed to update pronouns: {response.status_code}"
                    }
            else:
                return {
                    "status": "failed",
                    "message": f"Failed to get user data: {user_response.status_code}"
                }
                
        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }

    def check_token(self, token: str, proxy: Optional[str] = None) -> Dict[str, Any]:
        """Check if a token is valid"""
        try:
            session = self.create_session(proxy)
            headers = self.get_headers(token)
            
            # Add random delay
            time.sleep(random.uniform(1, 2))
            
            # Get user data to check token
            response = session.get(
                "https://discord.com/api/v9/users/@me",
                headers=headers,
                timeout_seconds=10
            )
            
            if response.status_code == 200:
                user_data = response.json()
                return {
                    "status": "valid",
                    "message": "Token is valid",
                    "data": user_data
                }
            elif response.status_code == 401:
                return {
                    "status": "invalid",
                    "message": "Invalid token"
                }
            elif response.status_code == 403:
                if "cloudflare" in response.text.lower():
                    return {
                        "status": "verify",
                        "message": "Token needs verification"
                    }
                return {
                    "status": "invalid",
                    "message": "Token is invalid"
                }
            else:
                return {
                    "status": "error",
                    "message": f"Error checking token: {response.status_code}"
                }
                
        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }

    def change_avatar(self, token, avatar_url, proxy=None):
        """Change avatar for a token using Discord CDN URL"""
        try:
            # Create session with proxy if provided
            session = self.create_session(proxy)
            headers = self.get_headers(token)
            
            # Get current user data
            response = session.get("https://discord.com/api/v9/users/@me", headers=headers, timeout_seconds=10)
            if response.status_code != 200:
                return {"status": "error", "message": f"Failed to get user data: {response.status_code}"}
            
            user_data = response.json()
            
            # Download avatar image
            try:
                # Use regular requests for downloading avatar
                avatar_response = requests.get(avatar_url, timeout=10)
                if avatar_response.status_code != 200:
                    return {"status": "error", "message": "Failed to download avatar image"}
                
                # Check content type
                content_type = avatar_response.headers.get('content-type', '')
                if not content_type.startswith('image/'):
                    return {"status": "error", "message": "URL is not an image"}
                
                # Get image data
                image_data = avatar_response.content
                
                # Check image size (Discord limit is 8MB)
                if len(image_data) > 8 * 1024 * 1024:
                    return {"status": "error", "message": "Image size exceeds 8MB limit"}
                
                # Convert image to base64
                avatar_base64 = base64.b64encode(image_data).decode('utf-8')
                
                # Prepare payload with only avatar field
                payload = {
                    "avatar": f"data:{content_type};base64,{avatar_base64}"
                }
                
                # Send request to change avatar
                response = session.patch(
                    "https://discord.com/api/v9/users/@me",
                    headers=headers,
                    json=payload,
                    timeout_seconds=10
                )
                
                if response.status_code == 200:
                    return {"status": "success", "message": "Avatar changed successfully"}
                elif response.status_code == 429:
                    retry_after = response.json().get('retry_after', 5)
                    time.sleep(retry_after)
                    return self.change_avatar(token, avatar_url, proxy)
                elif response.status_code == 403:
                    return {"status": "captcha", "message": "Captcha required"}
                elif response.status_code == 401:
                    return {"status": "invalid", "message": "Invalid token"}
                else:
                    error_msg = response.text
                    try:
                        error_data = response.json()
                        error_msg = error_data.get('message', error_msg)
                    except:
                        pass
                    return {"status": "error", "message": f"Failed to change avatar: {error_msg}"}
                
            except requests.exceptions.Timeout:
                return {"status": "error", "message": "Timeout while downloading avatar"}
            except requests.exceptions.RequestException as e:
                return {"status": "error", "message": f"Error downloading avatar: {str(e)}"}
            except Exception as e:
                return {"status": "error", "message": f"Error processing avatar: {str(e)}"}
            
        except Exception as e:
            return {"status": "error", "message": str(e)} 