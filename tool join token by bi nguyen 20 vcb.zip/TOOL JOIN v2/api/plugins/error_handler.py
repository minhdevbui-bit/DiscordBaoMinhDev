import traceback
from .log import log

class ErrorHandler:
    def __init__(self):
        self.errors = []

    def handle(self, error, token=None):
        error_msg = f"{str(error)}\n{traceback.format_exc()}"
        self.errors.append(error_msg)
        
        if token:
            with open('output/errors.txt', 'a', encoding='utf-8') as f:
                f.write(f"Token: {token}\nError: {error_msg}\n\n")
        
        log.error(f"Error occurred: {str(error)}")

error_handler = ErrorHandler() 