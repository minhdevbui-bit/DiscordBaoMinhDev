import tls_client
import random
from .log import log

class Client:
    def __init__(self):
        self.session = None

    def create_session(self, proxy=None):
        try:
            session = tls_client.Session(
                client_identifier="chrome_120",
                random_tls_extension_order=True,
                ja3_string="771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-21,29-23-24,0",
                h2_settings={
                    "HEADER_TABLE_SIZE": 65536,
                    "MAX_CONCURRENT_STREAMS": 1000,
                    "INITIAL_WINDOW_SIZE": 6291456,
                    "MAX_HEADER_LIST_SIZE": 262144
                },
                h2_settings_order=[
                    "HEADER_TABLE_SIZE",
                    "MAX_CONCURRENT_STREAMS",
                    "INITIAL_WINDOW_SIZE",
                    "MAX_HEADER_LIST_SIZE"
                ],
                supported_signature_algorithms=[
                    "ECDSAWithP256AndSHA256",
                    "PSSWithSHA256",
                    "PKCS1WithSHA256",
                    "ECDSAWithP384AndSHA384",
                    "PSSWithSHA384",
                    "PKCS1WithSHA384",
                    "PSSWithSHA512",
                    "PKCS1WithSHA512",
                ],
                supported_versions=["GREASE", "1.3", "1.2"],
                key_share_curves=["GREASE", "X25519"],
                cert_compression_algo="brotli",
                pseudo_header_order=[
                    ":method",
                    ":authority",
                    ":scheme",
                    ":path"
                ],
                connection_flow=15663105,
                header_order=[
                    "accept",
                    "user-agent",
                    "accept-language",
                    "accept-encoding",
                    "content-type",
                    "authorization",
                    "origin",
                    "referer",
                    "sec-ch-ua",
                    "sec-ch-ua-mobile",
                    "sec-ch-ua-platform",
                    "sec-fetch-dest",
                    "sec-fetch-mode",
                    "sec-fetch-site",
                    "x-debug-options",
                    "x-discord-locale",
                    "x-super-properties"
                ]
            )
            
            if proxy:
                session.proxies = {
                    "http": f"http://{proxy}",
                    "https": f"http://{proxy}"
                }
            
            session.verify = False
            self.session = session
            return session
            
        except Exception as e:
            log.error(f"Failed to create session: {str(e)}")
            return None

    def get_headers(self, token, invite_code=None):
        headers = {
            "authorization": token,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "accept-encoding": "gzip, deflate, br",
            "content-type": "application/json",
            "origin": "https://discord.com",
            "referer": f"https://discord.com/invite/{invite_code}" if invite_code else "https://discord.com",
            "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTIwLjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjI2MDM0OSwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0="
        }
        return headers

client = Client() 