import threading
import queue
import time
import random
from colorama import init, Fore, Back, Style
from api import *
from api.plugins.dchelper import DiscordHelper
import concurrent.futures
import os
import requests

def remove_token_from_file(token):
    """Remove a token from tokens.txt after processing"""
    try:
        # Read all tokens
        with open('input/tokens.txt', 'r', encoding='utf-8') as f:
            tokens = f.read().splitlines()
        
        # Remove the processed token
        if token in tokens:
            tokens.remove(token)
            
        # Write back remaining tokens
        with open('input/tokens.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(tokens))
    except Exception as e:
        log.error(f"Error updating tokens.txt: {str(e)}")

def clear_output_files():
    """Clear all output files when new tokens.txt is loaded"""
    try:
        # Create output folder if it doesn't exist
        if not os.path.exists("output"):
            os.makedirs("output")
            log.info("Đã tạo folder output")
            
        # List of all output files
        output_files = [
            "joined.txt",
            "left.txt",
            "name_changed.txt",
            "pronouns_changed.txt",
            "invalid_tokens.txt",
            "captcha.txt",
            "cloudflare.txt",
            "failed.txt",
            "failed_leave.txt",
            "errors.txt",
            "valid_tokens.txt",
            "verify_tokens.txt",
            "error_tokens.txt",
            "avatar_changed.txt"  # Thêm file cho avatar
        ]
        
        # Create each file if it doesn't exist
        for file in output_files:
            file_path = os.path.join("output", file)
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    pass
                log.info(f"Đã tạo file {file}")
                
    except Exception as e:
        log.error(f"Lỗi khi tạo cấu trúc output: {str(e)}")

def process_avatar_change(token, avatar_url, proxy=None):
    """Process changing avatar for a single token"""
    try:
        display_token = f"{token[:20]}...{token[-10:]}"
        log.info(f"Đang xử lý token: {display_token}")
        
        # Kiểm tra token trước khi đổi avatar
        dc_helper = DiscordHelper()
        token_status = dc_helper.check_token(token, proxy)
        if token_status["status"] != "valid":
            log.error(f"Token không hợp lệ, bỏ qua: {display_token}")
            file_manager.save_result("invalid_tokens.txt", token)
            remove_token_from_file(token)
            return False
            
        # Thử đổi avatar
        result = dc_helper.change_avatar(token, avatar_url, proxy)
        
        if result["status"] == "success":
            log.success(f"[ Thành công ] {display_token} đã đổi avatar")
            file_manager.save_result("avatar_changed.txt", token)
            remove_token_from_file(token)
            return True
        elif result["status"] == "captcha":
            log.captcha(f"{display_token} token đã bị dính capcha, bỏ qua")
            file_manager.save_result("captcha.txt", token)
            remove_token_from_file(token)
        elif result["status"] == "verify":
            log.verification(f"{display_token} token cần xác minh, bỏ qua")
            file_manager.save_result("verify_tokens.txt", token)
            remove_token_from_file(token)
        elif "Unknown Session" in str(result.get("message", "")):
            log.error(f"{display_token} token đã hết hạn, bỏ qua")
            file_manager.save_result("invalid_tokens.txt", token)
            remove_token_from_file(token)
        else:
            log.error(f"{display_token} lỗi: {result.get('message', 'Unknown error')}")
            file_manager.save_result("error_tokens.txt", token)
            remove_token_from_file(token)
        
        return False
    except Exception as e:
        log.error(f"Lỗi khi xử lý token {display_token}: {str(e)}")
        return False

def change_avatars(avatar_url):
    """Change avatars for all tokens"""
    try:
        tokens = file_manager.gettokens()
        if not tokens:
            log.error("Không tìm thấy token nào trong file tokens.txt")
            return False
            
        # Clear old tokens from output files
        clear_output_files()
        
        proxies = file_manager.getproxies() if file_manager.getproxystatus() else []
        
        log.info(f"Đang xử lý {len(tokens)} token...")
        
        # Thread-safe counter
        success_count = 0
        fail_count = 0
        
        # Queue for used proxies
        used_proxies = queue.Queue()
        
        # Calculate optimal number of threads based on token count
        if len(tokens) > 50:
            max_threads = min(500, len(tokens)) if proxies else min(500, len(tokens))
        else:
            max_threads = min(500, len(tokens)) if proxies else min(500, len(tokens))
        
        log.info(f"Starting {max_threads} threads...")
        
        def process_token_batch(token_batch):
            nonlocal success_count, fail_count
            for token in token_batch:
                proxy = None
                if proxies:
                    try:
                        proxy = proxies.pop(0)
                        used_proxies.put(proxy)
                    except:
                        pass
                
                if process_avatar_change(token, avatar_url, proxy):
                    success_count += 1
                else:
                    fail_count += 1
                
                # Add minimal delay between tokens
                time.sleep(random.uniform(0.0001, 0.0003))  # giảm delay xuống 0.1-0.3ms
        
        # Process tokens in smaller batches for better performance
        batch_size = 1
        token_batches = [tokens[i:i + batch_size] for i in range(0, len(tokens), batch_size)]
        
        # Process batches with ThreadPoolExecutor
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = []
            for batch in token_batches:
                futures.append(executor.submit(process_token_batch, batch))
            
            # Wait for all tasks to complete
            concurrent.futures.wait(futures)
        
        # Log results
        log.info(f"\nKết quả:")
        log.info(f"Thành công: {success_count}")
        log.info(f"Thất bại: {fail_count}")
        log.info(f"Còn lại: {len(tokens) - (success_count + fail_count)}")
        
        return True
        
    except Exception as e:
        log.error(f"Lỗi: {str(e)}")
        return False 